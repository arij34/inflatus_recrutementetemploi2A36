// Création d'un tableau et passage du numéro, des questions, des options et des réponses
let questions = [
{
numb: 1,
question: "Que signifie HTML ?",
answer: "Hyper Text Markup Language",
options: [
"Hyper Text Preprocessor",
"Hyper Text Markup Language",
"Hyper Text Multiple Language",
"Hyper Tool Multi Language"
]
},
{
numb: 2,
question: "Que signifie CSS ?",
answer: "Cascading Style Sheet",
options: [
"Common Style Sheet",
"Colorful Style Sheet",
"Computer Style Sheet",
"Cascading Style Sheet"
]
},
{
numb: 3,
question: "Que signifie PHP ?",
answer: "Hypertext Preprocessor",
options: [
"Hypertext Preprocessor",
"Hypertext Programming",
"Hypertext Preprogramming",
"Hometext Preprocessor"
]
},
{
numb: 4,
question: "Que signifie SQL ?",
answer: "Structured Query Language",
options: [
"Stylish Question Language",
"Stylesheet Query Language",
"Statement Question Language",
"Structured Query Language"
]
},
{
numb: 5,
question: "Que signifie XML ?",
answer: "eXtensible Markup Language",
options: [
"eXtensible Markup Language",
"eXecutable Multiple Language",
"eXTra Multi-Program Language",
"eXamine Multiple Language"
]
},
// Vous pouvez décommenter les codes ci-dessous et en ajouter autant que vous le souhaitez pour ajouter des questions
// mais rappelez-vous que vous devez donner une valeur de numéro sérialisée comme 1,2,3,5,6,7,8,9.....
// {
// numb: 6,
// question: "Votre question est ici",
// answer: "La réponse correcte de la question est ici",
// options: [
// "Option 1",
// "option 2",
// "option 3",
// "option 4"
// ]
// },
];